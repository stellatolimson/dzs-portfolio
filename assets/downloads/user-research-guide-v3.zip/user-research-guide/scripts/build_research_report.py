#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_research_report.py
基于 assets/report-business.html（单页纵向滚动、商务风）生成完整调研方案 HTML 报告。
与翻页 PPT 不同：本输出可上下滑动、内容紧凑、无需翻页。

用法：
  python build_research_report.py \
    --theme "早安盒子" \
    --date "2026-08-21" \
    --lead "一线城市 22-35 岁职场人晨间通勤场景下健康早餐订阅服务调研" \
    --goal "验证目标人群是否愿为提前订阅的健康早餐付费" \
    --deadline "2026-09-18" \
    --weeks 4 \
    --author "Stella" \
    --output report.html
"""
import argparse
from pathlib import Path


def load(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fill(html: str, args) -> str:
    repl = {
        "[THEME]": args.theme,
        "[DATE]": args.date,
        "[DEADLINE]": args.deadline,
        "[WEEKS]": str(args.weeks),
        "[AUTHOR]": args.author,
        "[GOAL]": args.goal,
        "[LEAD]": args.lead or args.goal,
    }
    for k, v in repl.items():
        html = html.replace(k, v)
    return html


def main():
    parser = argparse.ArgumentParser(description="生成单页滚动商务风调研方案 HTML")
    parser.add_argument("--theme", default="用户调研主题", help="调研主题名称")
    parser.add_argument("--date", default="2026-08-21", help="方案日期")
    parser.add_argument("--lead", default="", help="一句话副标题/背景")
    parser.add_argument("--goal", default="", help="调研核心问题")
    parser.add_argument("--deadline", default="2026-09-18", help="交付 deadline")
    parser.add_argument("--weeks", type=int, default=4, help="总周期周数")
    parser.add_argument("--author", default="Stella", help="负责人")
    parser.add_argument("--output", default="research-report.html", help="输出 HTML 路径")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent / "assets"
    template = base / "report-business.html"
    html = fill(load(template), args)

    out = Path(args.output)
    out.write_text(html, encoding="utf-8")
    print(f"✅ 已生成商务风调研报告: {out.absolute()}")


if __name__ == "__main__":
    main()
