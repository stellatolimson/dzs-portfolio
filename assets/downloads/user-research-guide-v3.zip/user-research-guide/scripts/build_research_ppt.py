#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_research_ppt.py
把 user-research-guide skill 里的调研方案内容拼接到 template-swiss.html 中，
生成一份可直接浏览器全屏演示的 HTML PPT。

用法示例：
  python build_research_ppt.py \
    --theme "早安盒子" \
    --date "2026-08-21" \
    --lead "一线城市 22-35 岁职场人晨间通勤场景下健康早餐订阅服务调研" \
    --goal "验证目标人群是否愿为'提前订阅、到站自提'的健康早餐付费" \
    --deadline "2026-09-18" \
    --weeks 4 \
    --author "Stella" \
    --output plan.html
"""
import argparse
import re
from pathlib import Path


def load(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def assemble_slides(slides_path: Path, gantt_path: Path) -> str:
    """将甘特图片段插入 slides-research-plan.html 的占位处。"""
    slides = load(slides_path)
    gantt = load(gantt_path)
    marker = "<!-- 请将 slide-gantt.html 中的 <section>...</section> 粘贴到此处 -->"
    if marker not in slides:
        # 如果已经插入或占位不同，直接追加
        return slides + "\n" + gantt
    return slides.replace(marker, gantt)


def inject_into_template(template_path: Path, slides_html: str) -> str:
    """把 slide 内容插入 template-swiss.html 的 SLIDES_HERE 注释之后。"""
    template = load(template_path)
    pattern = r"(<!--\s*SLIDES_HERE[\s\S]*?-->)"
    match = re.search(pattern, template)
    if not match:
        raise RuntimeError("未在 template-swiss.html 中找到 SLIDES_HERE 占位注释")
    insert_after = match.end()
    return template[:insert_after] + "\n" + slides_html + "\n" + template[insert_after:]


def fill_placeholders(html: str, args) -> str:
    """替换常见占位符。无法自动填充的保持原样，供用户二次编辑。"""
    replacements = {
        "[主题名称]": args.theme,
        "[日期]": args.date,
        "[负责人]": args.author,
        "[团队]": args.team or args.author,
        "[核心问题]": args.goal,
        "[一句话说明这次调研要回答什么业务问题。]": args.goal,
        "[总周期]": str(args.weeks),
        "[N 周]": str(args.weeks),
        "[N 周] · 交付 [YYYY-MM-DD]": f"{args.weeks} 周 · 交付 {args.deadline}",
        "总周期 [N] 周 · 交付 [YYYY-MM-DD]": f"总周期 {args.weeks} 周 · 交付 {args.deadline}",
        "[YYYY-MM-DD]": args.deadline,
    }
    for old, new in replacements.items():
        html = html.replace(old, new)
    return html


def adjust_gantt_weeks(html: str, weeks: int) -> str:
    """根据总周数调整甘特图列数（简单替换表头）。"""
    if weeks == 4:
        return html
    week_labels = "".join(f'<span>第{w}周</span>' for w in range(1, weeks + 1))
    html = re.sub(
        r'(<div class="gantt-weeks">)[\s\S]*?(</div>)',
        rf'\1\n          {week_labels}\n        \2',
        html,
        count=1,
    )
    # 同步 grid-template-columns
    html = re.sub(
        r'grid-template-columns:minmax\(120px,10vw\) repeat\(\d+,1fr\)',
        f'grid-template-columns:minmax(120px,10vw) repeat({weeks},1fr)',
        html,
    )
    return html


def main():
    parser = argparse.ArgumentParser(description="生成用户调研方案 HTML PPT")
    parser.add_argument("--theme", default="用户调研主题", help="调研主题名称")
    parser.add_argument("--date", default="2026-08-21", help="方案日期")
    parser.add_argument("--lead", default="", help="一句话副标题/背景")
    parser.add_argument("--goal", default="", help="调研核心问题")
    parser.add_argument("--deadline", default="2026-09-18", help="交付 deadline")
    parser.add_argument("--weeks", type=int, default=4, help="总周期周数")
    parser.add_argument("--author", default="Stella", help="负责人")
    parser.add_argument("--team", default="", help="团队/组织")
    parser.add_argument("--output", default="research-plan.html", help="输出 HTML 路径")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent / "assets"
    template_path = base / "template-swiss.html"
    slides_path = base / "slides-research-plan.html"
    gantt_path = base / "slide-gantt.html"

    slides_html = assemble_slides(slides_path, gantt_path)
    html = inject_into_template(template_path, slides_html)
    html = fill_placeholders(html, args)
    html = adjust_gantt_weeks(html, args.weeks)

    if args.lead:
        html = html.replace(
            "基于 7 步调研流程：明确目标 → 假设先行 → 设计方案 → 组织实施 → 信息整理 → 输出 Insight → 同步复盘。",
            args.lead,
        )

    output_path = Path(args.output)
    output_path.write_text(html, encoding="utf-8")
    print(f"✅ 已生成 HTML PPT: {output_path.absolute()}")


if __name__ == "__main__":
    main()
