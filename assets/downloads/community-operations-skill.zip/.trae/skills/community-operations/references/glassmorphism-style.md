# Glassmorphism CSS 设计系统

> 本文件定义社群运营 SOP HTML 输出的视觉设计规范。所有 HTML 输出必须严格遵循此设计系统。

---

## 色彩系统

### 主色调

| 变量名 | 色值 | 用途 |
|--------|------|------|
| `--bg-deep` | `#0a0e27` | 页面最深背景 |
| `--bg-mid` | `#141b3d` | 内容区背景 |
| `--bg-card` | `rgba(20, 27, 61, 0.6)` | 卡片背景（半透明） |
| `--primary` | `#6366f1` | 主强调色（靛蓝紫） |
| `--primary-light` | `#818cf8` | 浅靛蓝紫 |
| `--accent-cyan` | `#06b6d4` | 青色强调 |
| `--accent-pink` | `#ec4899` | 品红强调 |
| `--accent-purple` | `#a855f7` | 紫色强调 |
| `--text-primary` | `#f0f4ff` | 主文字色 |
| `--text-secondary` | `#94a3b8` | 次要文字色 |
| `--text-muted` | `#64748b` | 静默文字色 |
| `--border-glow` | `rgba(99, 102, 241, 0.3)` | 发光边框 |
| `--glass-blur` | `blur(12px)` | 毛玻璃模糊值 |

### 渐变定义

```css
/* 页面背景渐变 */
--gradient-bg: radial-gradient(ellipse at center, #141b3d 0%, #0a0e27 100%);

/* 主标题渐变 */
--gradient-title: linear-gradient(135deg, #818cf8 0%, #06b6d4 50%, #a855f7 100%);

/* 卡片高光渐变 */
--gradient-card: linear-gradient(135deg, rgba(99, 102, 241, 0.08) 0%, rgba(168, 85, 247, 0.05) 100%);

/* 分割线渐变 */
--gradient-divider: linear-gradient(90deg, transparent 0%, rgba(99, 102, 241, 0.3) 50%, transparent 100%);
```

---

## 字体规范

```css
--font-title: 'Noto Serif SC', 'Songti SC', 'SimSun', serif;       /* 标题：衬线 */
--font-body: 'Noto Sans SC', 'PingFang SC', 'Microsoft YaHei', sans-serif; /* 正文：无衬线 */
--font-mono: 'JetBrains Mono', 'Courier New', monospace;           /* 数据/标签 */
```

| 元素 | 字号 | 字重 | 字间距 |
|------|------|------|--------|
| 页面主标题 | 2.5rem | 700 | 0.05em |
| 板块标题 | 1.75rem | 600 | 0.03em |
| 卡片标题 | 1.25rem | 600 | 0.02em |
| 正文内容 | 0.95rem | 400 | normal |
| 标签/频次 | 0.75rem | 500 | 0.05em |
| 数据指标 | 2rem | 700 | normal |

---

## 玻璃拟态卡片样式

### 标准玻璃卡片

```css
.glass-card {
  background: var(--bg-card);
  backdrop-filter: var(--glass-blur);
  -webkit-backdrop-filter: var(--glass-blur);
  border: 1px solid var(--border-glow);
  border-radius: 16px;
  padding: 28px;
  box-shadow: 
    0 4px 30px rgba(0, 0, 0, 0.3),
    inset 0 1px 0 rgba(255, 255, 255, 0.05);
  transition: all 0.3s ease;
}

.glass-card:hover {
  border-color: rgba(99, 102, 241, 0.5);
  box-shadow: 
    0 8px 40px rgba(99, 102, 241, 0.15),
    inset 0 1px 0 rgba(255, 255, 255, 0.08);
  transform: translateY(-2px);
}
```

### 强调卡片（板块容器）

```css
.glass-section {
  background: linear-gradient(135deg, rgba(20, 27, 61, 0.8) 0%, rgba(10, 14, 39, 0.6) 100%);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(99, 102, 241, 0.2);
  border-radius: 24px;
  padding: 40px;
  margin-bottom: 32px;
  box-shadow: 0 4px 50px rgba(0, 0, 0, 0.4);
}
```

### 数据指标卡片

```css
.metric-card {
  background: rgba(99, 102, 241, 0.08);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(99, 102, 241, 0.25);
  border-radius: 12px;
  padding: 20px;
  text-align: center;
}

.metric-value {
  font-size: 2rem;
  font-weight: 700;
  background: var(--gradient-title);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
```

---

## 标签样式

### 频次标签

```css
.freq-tag {
  display: inline-block;
  font-family: var(--font-mono);
  font-size: 0.7rem;
  font-weight: 500;
  padding: 3px 10px;
  border-radius: 20px;
  letter-spacing: 0.05em;
}

/* 不同频次的颜色变体 */
.freq-tag.daily   { background: rgba(6, 182, 212, 0.15); color: #67e8f9; border: 1px solid rgba(6, 182, 212, 0.3); }
.freq-tag.weekly  { background: rgba(99, 102, 241, 0.15); color: #a5b4fc; border: 1px solid rgba(99, 102, 241, 0.3); }
.freq-tag.monthly { background: rgba(168, 85, 247, 0.15); color: #c4b5fd; border: 1px solid rgba(168, 85, 247, 0.3); }
.freq-tag.event   { background: rgba(236, 72, 153, 0.15); color: #f9a8d4; border: 1px solid rgba(236, 72, 153, 0.3); }
```

### 内容类型标签

```css
.type-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 0.75rem;
  font-weight: 600;
  padding: 4px 12px;
  border-radius: 6px;
}

.type-tag.dry-goods { background: rgba(6, 182, 212, 0.12); color: #67e8f9; }
.type-tag.interact  { background: rgba(168, 85, 247, 0.12); color: #c4b5fd; }
.type-tag.benefit   { background: rgba(236, 72, 153, 0.12); color: #f9a8d4; }
.type-tag.conversion{ background: rgba(99, 102, 241, 0.12); color: #a5b4fc; }
```

---

## 布局规范

### 页面结构

```
┌─────────────────────────────────────────┐
│  [页头] 品牌名 · 社群类型 · 日期标签    │
├─────────────────────────────────────────┤
│  [Hero] 社群运营SOP 主标题 + 副标题      │
├─────────────────────────────────────────┤
│  [板块1] 社群定位概览（三列卡片）        │
├─────────────────────────────────────────┤
│  [板块2] 社群布局（链路 + 群信息 + 内容）│
├─────────────────────────────────────────┤
│  [板块3] 精细化运营（最详细板块）        │
│    ├ 基础设置                            │
│    ├ 日常运营方案表                      │
│    ├ 群发内容                            │
│    ├ 用户分层1v1运营表                   │
│    └ 数据复盘指标卡                      │
├─────────────────────────────────────────┤
│  [板块4] 社群转化（种草+限时+客服）      │
├─────────────────────────────────────────┤
│  [板块5] 避雷指南（三列警示卡片）        │
└─────────────────────────────────────────┘
```

### 响应式网格

```css
/* 三列网格 */
.grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
/* 两列网格 */
.grid-2 { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
/* 自适应网格 */
.grid-auto { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }

@media (max-width: 768px) {
  .grid-3, .grid-2, .grid-auto { grid-template-columns: 1fr; }
}
```

---

## 装饰元素

### 背景粒子效果

```css
body::before {
  content: '';
  position: fixed;
  top: 0; left: 0; width: 100%; height: 100%;
  background: 
    radial-gradient(circle at 15% 20%, rgba(99, 102, 241, 0.08) 0%, transparent 40%),
    radial-gradient(circle at 85% 80%, rgba(168, 85, 247, 0.06) 0%, transparent 40%),
    radial-gradient(circle at 50% 50%, rgba(6, 182, 212, 0.04) 0%, transparent 30%);
  pointer-events: none;
  z-index: 0;
}
```

### 板块序号徽章

```css
.section-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 36px; height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, #6366f1, #a855f7);
  font-family: var(--font-mono);
  font-size: 0.85rem;
  font-weight: 700;
  color: #fff;
  box-shadow: 0 0 20px rgba(99, 102, 241, 0.4);
}
```

### 渐变分割线

```css
.divider {
  height: 1px;
  background: var(--gradient-divider);
  margin: 24px 0;
  border: none;
}
```

---

## 表格样式

```css
.sop-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}

.sop-table thead th {
  text-align: left;
  padding: 12px 16px;
  color: var(--text-secondary);
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid var(--border-glow);
}

.sop-table tbody tr {
  border-bottom: 1px solid rgba(99, 102, 241, 0.1);
  transition: background 0.2s;
}

.sop-table tbody tr:hover {
  background: rgba(99, 102, 241, 0.05);
}

.sop-table tbody td {
  padding: 14px 16px;
  color: var(--text-primary);
}
```

---

## 动画

```css
/* 入场动画 */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

.glass-card, .glass-section {
  animation: fadeInUp 0.6s ease-out backwards;
}

/* 逐级延迟 */
.glass-section:nth-child(1) { animation-delay: 0.1s; }
.glass-section:nth-child(2) { animation-delay: 0.2s; }
.glass-section:nth-child(3) { animation-delay: 0.3s; }
.glass-section:nth-child(4) { animation-delay: 0.4s; }
.glass-section:nth-child(5) { animation-delay: 0.5s; }

/* 发光脉动 */
@keyframes glowPulse {
  0%, 100% { box-shadow: 0 0 20px rgba(99, 102, 241, 0.3); }
  50%      { box-shadow: 0 0 30px rgba(99, 102, 241, 0.5); }
}

.section-badge {
  animation: glowPulse 3s ease-in-out infinite;
}
```
